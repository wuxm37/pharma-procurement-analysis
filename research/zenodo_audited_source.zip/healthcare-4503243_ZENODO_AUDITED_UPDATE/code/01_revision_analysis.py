#!/usr/bin/env python3
"""Revised longitudinal and simulation analyses for healthcare-4503243.

The script uses only the 48 anonymized monthly requested-demand observations
and cost inputs deposited in Zenodo record 21456323.  It produces every CSV,
LaTeX table, and figure referenced by manuscript_revised.tex.

Main revisions implemented here:
  * expanding-window rolling-origin evaluation for months 37--48;
  * transparent monthly holding cost (annual CLP 14.32 / 12);
  * scenario-based two-stage stochastic programming with shortage/overstock recourse;
  * an unconstrained diagnostic plus dual service-constrained SC95 and SC99 programs;
  * reproducible historical-mean, previous-month, and seasonal-naive baselines;
  * normal, gamma, NBII, ZINBI, and hurdle-NB marginal candidate distributions;
  * a prespecified temporal branch comparing Gaussian GLM and GARMA(1,0)/(2,0) scenario models when training data show temporal structure;
  * randomized 900-case simulation with 12 prospective periods per case;
  * development/test separation for the exploratory classification tree;
  * publication-ready tables and high-resolution PDF/PNG figures.
"""
from __future__ import annotations

import argparse
import os
import json
import math
import zlib
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import optimize, stats
from statsmodels.stats.diagnostic import acorr_ljungbox
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "data" / "source_zenodo"
OUT_DATA = ROOT / "data" / "revised"
OUT_TABLES = ROOT / "tables" / "revised"
OUT_FIGURES = ROOT / "figures" / "revised"
for path in (OUT_DATA, OUT_TABLES, OUT_FIGURES):
    path.mkdir(parents=True, exist_ok=True)

MODELS = ("NO", "GA", "NBII", "ZINBI", "HNB")
MODEL_LABELS = {
    "NO": "Normal", "GA": "Gamma", "NBII": "NBII",
    "ZINBI": "ZINBI", "HNB": "Hurdle-NB",
}
TEMPORAL_LABELS = {"G0T":"Gaussian GLM + trend", "G1":"GARMA(1,0)", "G1T":"GARMA(1,0) + trend", "G2":"GARMA(2,0)", "G2T":"GARMA(2,0) + trend"}
TEMPORAL_CODES = tuple(TEMPORAL_LABELS)

MODEL_COLORS = {
    "NO": "#3B82F6", "GA": "#F59E0B", "NBII": "#10B981",
    "ZINBI": "#8B5CF6", "HNB": "#EF4444", "TIE": "#9CA3AF",
}
SEED = 20260901
EMPIRICAL_SAA_SCENARIOS = 1024
SIMULATION_SAA_SCENARIOS = 256


def inv_logit(x: float) -> float:
    return float(1.0 / (1.0 + np.exp(-np.clip(x, -35, 35))))


def aic(ll: float, k: int) -> float:
    return float(2 * k - 2 * ll)


@dataclass
class Fit:
    model: str
    params: Dict[str, float]
    loglik: float
    aic: float

    def pmf_or_pdf(self, x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, dtype=float)
        p = self.params
        if self.model == "NO" or self.model in TEMPORAL_CODES:
            return stats.norm.pdf(x, p["mu"], p["sigma"])
        if self.model == "GA":
            return stats.gamma.pdf(x, p["shape"], loc=0, scale=p["scale"])
        if self.model == "NBII":
            return stats.nbinom.pmf(np.rint(x), p["r"], p["prob"])
        if self.model == "ZINBI":
            y = np.rint(x)
            base = stats.nbinom.pmf(y, p["r"], p["prob"])
            return np.where(y == 0, p["pi"] + (1 - p["pi"]) * base, (1 - p["pi"]) * base)
        if self.model == "HNB":
            y = np.rint(x)
            p0_nb = stats.nbinom.pmf(0, p["r"], p["prob"])
            pos = (1 - p["pi0"]) * stats.nbinom.pmf(y, p["r"], p["prob"]) / max(1 - p0_nb, 1e-12)
            return np.where(y == 0, p["pi0"], pos)
        raise ValueError(self.model)

    def cdf(self, x: np.ndarray | float) -> np.ndarray:
        x = np.asarray(x, dtype=float)
        p = self.params
        if self.model == "NO" or self.model in TEMPORAL_CODES:
            return stats.norm.cdf(x, p["mu"], p["sigma"])
        if self.model == "GA":
            return stats.gamma.cdf(x, p["shape"], loc=0, scale=p["scale"])
        y = np.floor(x)
        if self.model == "NBII":
            return stats.nbinom.cdf(y, p["r"], p["prob"])
        if self.model == "ZINBI":
            return p["pi"] + (1 - p["pi"]) * stats.nbinom.cdf(y, p["r"], p["prob"])
        if self.model == "HNB":
            p0_nb = stats.nbinom.pmf(0, p["r"], p["prob"])
            positive_cdf = (stats.nbinom.cdf(y, p["r"], p["prob"]) - p0_nb) / max(1 - p0_nb, 1e-12)
            positive_cdf = np.clip(positive_cdf, 0, 1)
            return np.where(y < 0, 0, p["pi0"] + (1 - p["pi0"]) * positive_cdf)
        raise ValueError(self.model)

    def ppf(self, q: float) -> int:
        q = float(np.clip(q, 1e-6, 1 - 1e-6))
        if self.model == "NO" or self.model in TEMPORAL_CODES:
            return max(0, int(round(stats.norm.ppf(q, self.params["mu"], self.params["sigma"]))))
        if self.model == "GA":
            return max(0, int(round(stats.gamma.ppf(q, self.params["shape"], loc=0, scale=self.params["scale"]))))
        hi = max(20, int(self.mean() * 2 + 10 * math.sqrt(max(self.variance(), 1))))
        while float(self.cdf(hi)) < q and hi < 10_000_000:
            hi *= 2
        lo = 0
        while lo < hi:
            mid = (lo + hi) // 2
            if float(self.cdf(mid)) >= q:
                hi = mid
            else:
                lo = mid + 1
        return int(lo)

    def mean(self) -> float:
        p = self.params
        if self.model == "NO" or self.model in TEMPORAL_CODES: return p["mu"]
        if self.model == "GA": return p["shape"] * p["scale"]
        nb_mean = p["r"] * (1 - p["prob"]) / p["prob"]
        if self.model == "NBII": return nb_mean
        if self.model == "ZINBI": return (1 - p["pi"]) * nb_mean
        if self.model == "HNB":
            p0_nb = stats.nbinom.pmf(0, p["r"], p["prob"])
            return (1 - p["pi0"]) * nb_mean / max(1 - p0_nb, 1e-12)
        raise ValueError(self.model)

    def variance(self) -> float:
        p = self.params
        if self.model == "NO" or self.model in TEMPORAL_CODES: return p["sigma"] ** 2
        if self.model == "GA": return p["shape"] * p["scale"] ** 2
        # Numerical moments keep mixture formulas concise and stable.
        upper = max(100, int(self.mean() + 12 * math.sqrt(max(self.mean(), 1))))
        xs = np.arange(0, upper + 1)
        probs = self.pmf_or_pdf(xs)
        probs = probs / max(probs.sum(), 1e-12)
        mu = float(np.sum(xs * probs))
        return float(np.sum((xs - mu) ** 2 * probs))

    def logscore(self, y: float) -> float:
        density = float(self.pmf_or_pdf(np.array([y]))[0])
        return float(-np.log(max(density, 1e-300)))


def fit_normal(x: np.ndarray) -> Fit:
    mu = float(np.mean(x)); sigma = max(float(np.std(x, ddof=0)), 1e-6)
    ll = float(np.sum(stats.norm.logpdf(x, mu, sigma)))
    return Fit("NO", {"mu": mu, "sigma": sigma}, ll, aic(ll, 2))


def fit_gamma(x: np.ndarray) -> Optional[Fit]:
    if np.any(x <= 0): return None
    shape, _, scale = stats.gamma.fit(x, floc=0)
    ll = float(np.sum(stats.gamma.logpdf(x, shape, loc=0, scale=scale)))
    return Fit("GA", {"shape": float(shape), "scale": float(scale)}, ll, aic(ll, 2))


def _nb_nll(theta: np.ndarray, x: np.ndarray) -> float:
    mu, alpha = np.exp(np.clip(theta, -20, 25))
    r = 1 / alpha; prob = r / (r + mu)
    return -float(np.sum(stats.nbinom.logpmf(x, r, prob)))


def fit_nbii(x: np.ndarray) -> Fit:
    mu0 = max(float(np.mean(x)), 1e-6)
    var0 = max(float(np.var(x)), mu0 + 1e-6)
    alpha0 = max((var0 - mu0) / mu0 ** 2, 1e-5)
    res = optimize.minimize(_nb_nll, np.log([mu0, alpha0]), args=(x,), method="L-BFGS-B", bounds=[(-20, 25), (-20, 12)], options={"maxiter":80,"maxfun":300,"ftol":1e-8})
    mu, alpha = np.exp(res.x); r = 1 / alpha; prob = r / (r + mu); ll = -float(res.fun)
    return Fit("NBII", {"mu": float(mu), "alpha": float(alpha), "r": float(r), "prob": float(prob)}, ll, aic(ll, 2))


def fit_zinbi(x: np.ndarray) -> Fit:
    nb = fit_nbii(x); z = float(np.mean(x == 0))
    starts = [0.001, max(0.01, min(z, 0.95)), 0.5]
    def nll(theta: np.ndarray) -> float:
        mu, alpha = np.exp(np.clip(theta[:2], -20, 25)); pi = inv_logit(theta[2])
        r = 1 / alpha; prob = r / (r + mu); nb0 = stats.nbinom.pmf(0, r, prob)
        ll0 = np.log(pi + (1 - pi) * nb0 + 1e-300)
        llp = np.log(1 - pi + 1e-300) + stats.nbinom.logpmf(x, r, prob)
        return -float(np.sum(np.where(x == 0, ll0, llp)))
    best = None
    for pi0 in starts:
        t0 = [np.log(nb.params["mu"]), np.log(nb.params["alpha"]), np.log(pi0 / (1 - pi0))]
        res = optimize.minimize(nll, t0, method="L-BFGS-B", bounds=[(-20, 25), (-20, 12), (-15, 15)], options={"maxiter":80,"maxfun":400,"ftol":1e-8})
        if best is None or res.fun < best.fun: best = res
    mu, alpha = np.exp(best.x[:2]); pi = inv_logit(best.x[2]); r = 1 / alpha; prob = r / (r + mu); ll = -float(best.fun)
    return Fit("ZINBI", {"mu": float(mu), "alpha": float(alpha), "pi": pi, "r": float(r), "prob": float(prob)}, ll, aic(ll, 3))


def fit_hurdle_nb(x: np.ndarray) -> Optional[Fit]:
    positive = x[x > 0]
    if len(positive) < 2: return None
    pi0 = float(np.mean(x == 0)); nb = fit_nbii(positive)
    def nll(theta: np.ndarray) -> float:
        mu, alpha = np.exp(np.clip(theta, -20, 25)); r = 1 / alpha; prob = r / (r + mu)
        p0 = stats.nbinom.pmf(0, r, prob)
        ll_pos = stats.nbinom.logpmf(positive, r, prob) - np.log(max(1 - p0, 1e-300))
        ll = len(x[x == 0]) * np.log(max(pi0, 1e-300)) + len(positive) * np.log(max(1 - pi0, 1e-300)) + np.sum(ll_pos)
        return -float(ll)
    res = optimize.minimize(nll, np.log([nb.params["mu"], nb.params["alpha"]]), method="L-BFGS-B", bounds=[(-20, 25), (-20, 12)], options={"maxiter":80,"maxfun":300,"ftol":1e-8})
    mu, alpha = np.exp(res.x); r = 1 / alpha; prob = r / (r + mu); ll = -float(res.fun)
    return Fit("HNB", {"mu": float(mu), "alpha": float(alpha), "pi0": pi0, "r": float(r), "prob": float(prob)}, ll, aic(ll, 3))


def fit_nbii_simulation(x: np.ndarray) -> Fit:
    """Stable intercept-only NBII MLE for randomized stress-test cases.

    For an intercept-only NBII model the fitted mean is anchored at the sample
    mean; only dispersion is optimized numerically. This one-dimensional form is
    materially more stable for extreme randomized counts than a two-parameter search.
    """
    x=np.asarray(x,dtype=float); mu=max(float(np.mean(x)),1e-8)
    var=max(float(np.var(x)),mu+1e-8); a0=max((var-mu)/(mu*mu),1e-6)
    def obj(loga: float) -> float:
        alpha=float(np.exp(np.clip(loga,-16,12))); r=1/alpha; prob=r/(r+mu)
        val=-float(np.sum(stats.nbinom.logpmf(x,r,prob)))
        return val if np.isfinite(val) else 1e300
    res=optimize.minimize_scalar(obj,bounds=(-16,12),method='bounded',options={'maxiter':80,'xatol':1e-5})
    loga=float(res.x) if np.isfinite(res.x) else math.log(a0); alpha=float(np.exp(loga)); r=1/alpha; prob=r/(r+mu); ll=-float(obj(loga))
    return Fit('NBII',{'mu':mu,'alpha':alpha,'r':r,'prob':prob},ll,aic(ll,2))


def fit_zinbi_simulation(x: np.ndarray) -> Fit:
    """Bounded single-start likelihood fit used only inside the 900-case stress test."""
    x=np.asarray(x,dtype=float); nb=fit_nbii_simulation(x); z=float(np.mean(x==0))
    nb_zero=float(stats.nbinom.pmf(0,nb.params['r'],nb.params['prob']))
    pi0=float(np.clip((z-nb_zero)/max(1-nb_zero,1e-8),0.001,0.90))
    def nll(theta: np.ndarray) -> float:
        mu,alpha=np.exp(np.clip(theta[:2],-20,25)); pi=inv_logit(theta[2]); r=1/alpha; prob=r/(r+mu); nb0=stats.nbinom.pmf(0,r,prob)
        ll0=np.log(pi+(1-pi)*nb0+1e-300); llp=np.log(1-pi+1e-300)+stats.nbinom.logpmf(x,r,prob)
        val=-float(np.sum(np.where(x==0,ll0,llp)))
        return val if np.isfinite(val) else 1e300
    t0=np.array([np.log(max(nb.params['mu'],1e-8)),np.log(max(nb.params['alpha'],1e-8)),np.log(pi0/(1-pi0))])
    res=optimize.minimize(nll,t0,method='L-BFGS-B',bounds=[(-20,25),(-20,12),(-12,12)],options={'maxiter':35,'maxfun':180,'ftol':1e-7})
    th=res.x if np.all(np.isfinite(res.x)) else t0; mu,alpha=np.exp(th[:2]); pi=inv_logit(th[2]); r=1/alpha; prob=r/(r+mu); ll=-float(nll(th))
    return Fit('ZINBI',{'mu':float(mu),'alpha':float(alpha),'pi':pi,'r':float(r),'prob':float(prob)},ll,aic(ll,3))


def fit_hurdle_nb_simulation(x: np.ndarray) -> Optional[Fit]:
    """Stable hurdle-NB likelihood fit for randomized stress-test cases."""
    x=np.asarray(x,dtype=float); positive=x[x>0]
    if len(positive)<2: return None
    pi0=float(np.mean(x==0)); nb=fit_nbii_simulation(positive)
    def nll(theta: np.ndarray) -> float:
        mu,alpha=np.exp(np.clip(theta,-20,25)); r=1/alpha; prob=r/(r+mu); p0=stats.nbinom.pmf(0,r,prob)
        if not np.isfinite(p0) or p0>=1: return 1e300
        ll_pos=stats.nbinom.logpmf(positive,r,prob)-np.log(max(1-p0,1e-300))
        ll=len(x[x==0])*np.log(max(pi0,1e-300))+len(positive)*np.log(max(1-pi0,1e-300))+np.sum(ll_pos)
        val=-float(ll); return val if np.isfinite(val) else 1e300
    t0=np.log([max(nb.params['mu'],1e-8),max(nb.params['alpha'],1e-8)])
    res=optimize.minimize(nll,t0,method='L-BFGS-B',bounds=[(-20,25),(-20,12)],options={'maxiter':35,'maxfun':160,'ftol':1e-7})
    th=res.x if np.all(np.isfinite(res.x)) else t0; mu,alpha=np.exp(th); r=1/alpha; prob=r/(r+mu); ll=-float(nll(th))
    return Fit('HNB',{'mu':float(mu),'alpha':float(alpha),'pi0':pi0,'r':float(r),'prob':float(prob)},ll,aic(ll,3))


def fit_all_simulation(x: np.ndarray) -> Dict[str, Optional[Fit]]:
    return {'NO':fit_normal(x),'GA':fit_gamma(x),'NBII':fit_nbii_simulation(x),'ZINBI':fit_zinbi_simulation(x),'HNB':fit_hurdle_nb_simulation(x)}

def fit_all(x: np.ndarray) -> Dict[str, Optional[Fit]]:
    return {"NO": fit_normal(x), "GA": fit_gamma(x), "NBII": fit_nbii(x), "ZINBI": fit_zinbi(x), "HNB": fit_hurdle_nb(x)}



def _aicc_from_ll(ll: float, k: int, n: int) -> float:
    a = aic(ll, k)
    return float(a + (2*k*(k+1))/(n-k-1)) if n > k + 1 else float("inf")


def fit_gaussian_garma(x: np.ndarray, p: int, trend: bool) -> Optional[Fit]:
    """Conditional Gaussian GARMA(p,0) with identity link.

    With a Gaussian response, identity link, and q=0, GARMA(p,0) reduces to a
    Gaussian autoregressive conditional-mean model. A deterministic linear time
    covariate is optionally included, consistent with the GARMA regression
    framework. All candidate orders are estimated on the same conditional sample
    beginning at lag 2 so their AICc values are directly comparable.
    """
    x=np.asarray(x,dtype=float)
    if len(x) < 12 or p not in (0,1,2): return None
    start=2; y=x[start:]; n=len(y)
    cols=[np.ones(n)]
    if trend:
        tt=np.arange(start,len(x),dtype=float)/max(len(x)-1,1)
        cols.append(tt)
    for lag in range(1,p+1):
        cols.append(x[start-lag:len(x)-lag])
    X=np.column_stack(cols)
    if n <= X.shape[1] + 1: return None
    beta=np.linalg.lstsq(X,y,rcond=None)[0]
    resid=y-X@beta
    sigma=max(float(np.sqrt(np.sum(resid**2)/n)),1e-6)
    ll=float(np.sum(stats.norm.logpdf(resid,0,sigma)))
    k=int(len(beta)+1)
    if p:
        phi=np.asarray(beta[-p:],dtype=float)
        if p==1 and abs(phi[0]) >= .995: return None
        if p==2:
            roots=np.roots([-phi[1],-phi[0],1.0])
            if np.any(np.abs(roots) <= 1.001): return None
    row=[1.0]
    if trend: row.append(len(x)/max(len(x)-1,1))
    for lag in range(1,p+1): row.append(float(x[-lag]))
    forecast=max(0.0,float(np.dot(np.asarray(row),beta)))
    if p==0 and trend: code="G0T"
    elif p==1 and trend: code="G1T"
    elif p==2 and trend: code="G2T"
    elif p==1: code="G1"
    elif p==2: code="G2"
    else: code="NO"
    params={"mu":forecast,"sigma":sigma,"p":float(p),"trend":float(trend),"AICc":_aicc_from_ll(ll,k,n),"n_cond":float(n)}
    for j,b in enumerate(beta): params[f"coef{j}"]=float(b)
    return Fit(code,params,ll,aic(ll,k))


def select_temporal_scenario_model(x: np.ndarray, marginal_winner: str) -> tuple[Optional[Fit], Dict[str,float|str|bool]]:
    """Prespecified temporal screening and GLM/GARMA selection for one origin.

    Trend and serial dependence are diagnosed using the training window only.
    A significant linear trend (p<0.10) makes a time-trend Gaussian GLM eligible.
    GARMA autoregressive terms are considered only when Ljung--Box evidence at
    lag 2 remains significant after detrending (or on the raw series when no
    trend is detected). This prevents deterministic trend from being mislabeled
    as autoregressive dependence. The Gaussian temporal branch is considered for
    recurrent-positive series or when Normal is already the marginal-AIC winner.
    Candidate models use a common conditional sample and AICc, and the selected
    temporal model must improve AICc by at least 2 relative to static Gaussian.
    """
    x=np.asarray(x,dtype=float); tt=np.arange(len(x),dtype=float)
    slope=stats.linregress(tt,x); trend_sig=bool(slope.pvalue < .10)
    try: lb_raw=float(acorr_ljungbox(x,lags=[2],return_df=True)["lb_pvalue"].iloc[0])
    except Exception: lb_raw=1.0
    detr=x-(slope.intercept+slope.slope*tt)
    try: lb_det=float(acorr_ljungbox(detr,lags=[2],return_df=True)["lb_pvalue"].iloc[0])
    except Exception: lb_det=1.0
    serial_sig=bool((lb_det if trend_sig else lb_raw) < .10)
    temporal_signal=bool(trend_sig or serial_sig)
    gaussian_eligible=bool(np.all(x>0) or marginal_winner=="NO")
    meta={"TemporalSignal":temporal_signal,"GaussianTemporalEligible":gaussian_eligible,"LjungBoxP2":lb_raw,"LjungBoxDetrendedP2":lb_det,"TrendP":float(slope.pvalue),"TrendSlope":float(slope.slope),"TemporalSelected":False,"TemporalModel":"None","TemporalAICc":np.nan,"StaticGaussianAICc":np.nan}
    if not (temporal_signal and gaussian_eligible): return None,meta
    candidates=[]
    static=fit_gaussian_garma(x,0,False)
    if static is not None: candidates.append(static)
    if trend_sig:
        f=fit_gaussian_garma(x,0,True)
        if f is not None: candidates.append(f)
        if serial_sig:
            for order in (1,2):
                f=fit_gaussian_garma(x,order,True)
                if f is not None: candidates.append(f)
    elif serial_sig:
        for order in (1,2):
            f=fit_gaussian_garma(x,order,False)
            if f is not None: candidates.append(f)
    if not candidates or static is None: return None,meta
    best=min(candidates,key=lambda f:f.params.get("AICc",np.inf))
    meta["StaticGaussianAICc"]=float(static.params.get("AICc",np.nan))
    if best.params.get("AICc",np.inf) > static.params.get("AICc",np.inf)-2.0 or best.model=="NO": return None,meta
    meta.update({"TemporalSelected":True,"TemporalModel":TEMPORAL_LABELS.get(best.model,best.model),"TemporalCode":best.model,"TemporalAICc":float(best.params["AICc"])})
    return best,meta


def target_cost(q: float, demand: float, unit: float, order_cost: float, hold_month: float, emergency_multiplier: float) -> Dict[str, float]:
    """Realized one-period cost after the first-stage regular-procurement quantity q is fixed."""
    q = max(float(q), 0); demand = max(float(demand), 0)
    short = max(demand - q, 0); over = max(q - demand, 0)
    cost = (order_cost if q > 0 else 0) + unit * q + hold_month * over + emergency_multiplier * unit * short
    fill = 1.0 if demand <= 0 else min(q, demand) / demand
    return {"Cost": cost, "Shortage": short, "Overstock": over, "FillRate": fill, "CycleService": float(short == 0)}


def _stable_seed(*parts: object, base: int = SEED) -> int:
    payload = "|".join(str(x) for x in parts).encode("utf-8")
    return int((base + zlib.crc32(payload)) % (2**32 - 1))


def sample_fit(fit: Fit, n: int, seed: int) -> np.ndarray:
    """Generate nonnegative integer demand scenarios from a fitted candidate model."""
    rng = np.random.default_rng(int(seed))
    p = fit.params
    if fit.model == "NO" or fit.model in TEMPORAL_CODES:
        y = rng.normal(p["mu"], p["sigma"], size=n)
    elif fit.model == "GA":
        y = rng.gamma(p["shape"], p["scale"], size=n)
    elif fit.model == "NBII":
        y = rng.negative_binomial(p["r"], p["prob"], size=n)
    elif fit.model == "ZINBI":
        inactive = rng.random(n) < p["pi"]
        y = rng.negative_binomial(p["r"], p["prob"], size=n)
        y[inactive] = 0
    elif fit.model == "HNB":
        inactive = rng.random(n) < p["pi0"]
        y = np.zeros(n, dtype=float)
        active = ~inactive
        if np.any(active):
            p0 = float(stats.nbinom.cdf(0, p["r"], p["prob"]))
            u = rng.random(int(active.sum()))
            probs = np.clip(p0 + u * max(1.0 - p0, 1e-12), p0 + 1e-12, 1 - 1e-12)
            y[active] = stats.nbinom.ppf(probs, p["r"], p["prob"])
            y[active] = np.maximum(y[active], 1)
    else:
        raise ValueError(fit.model)
    return np.maximum(np.rint(y), 0).astype(int)


def _scenario_moments(q: int, sorted_d: np.ndarray, prefix: np.ndarray) -> Dict[str, float]:
    """O(log M) recourse/service moments for one integer q."""
    q = int(max(q, 0)); n = len(sorted_d); total = float(prefix[-1])
    idx = int(np.searchsorted(sorted_d, q, side="right"))
    sum_le = float(prefix[idx])
    shortage_sum = (total - sum_le) - q * (n - idx)
    overstock_sum = q * idx - sum_le
    cycle = idx / max(n, 1)
    fill = 1.0 if total <= 0 else float(np.clip(1.0 - shortage_sum / total, 0.0, 1.0))
    return {"ShortageSum": max(shortage_sum, 0.0), "OverstockSum": max(overstock_sum, 0.0), "ScenarioFillRate": fill, "ScenarioCycleService": float(cycle)}


def two_stage_saa_target(
    fit: Fit,
    unit: float,
    order_cost: float,
    hold_month: float,
    emergency_multiplier: float,
    *,
    alpha_min: Optional[float] = None,
    beta_min: Optional[float] = None,
    scenario_count: int = 512,
    seed: int = SEED,
) -> tuple[int, Dict[str, float]]:
    """Solve the finite-scenario two-stage stochastic program exactly over integer q.

    First stage: choose regular-procurement quantity q before demand is observed.
    Second stage: for each scenario m, shortage S_m=(D_m-q)^+ and overstock
    O_m=(q-D_m)^+ are recourse variables. The objective is the sample-average
    procurement + holding + emergency-procurement cost. Optional Type-I and
    Type-II service floors are imposed on the same predictive scenario set.

    The deterministic equivalent is one-dimensional and piecewise linear. Its
    optimum is found exactly at scenario breakpoints (plus the smallest integer
    service-feasible q), so the reproducibility package requires no external MILP solver.
    """
    scenarios = sample_fit(fit, int(scenario_count), int(seed)).astype(int)
    d = np.sort(scenarios)
    n = len(d)
    prefix = np.concatenate(([0.0], np.cumsum(d, dtype=float)))
    total = float(prefix[-1])

    service_lb = 0
    if alpha_min is not None:
        alpha = float(np.clip(alpha_min, 0.0, 1.0))
        idx = max(0, min(n-1, int(math.ceil(alpha*n)) - 1))
        service_lb = max(service_lb, int(d[idx]))
    if beta_min is not None:
        beta = float(np.clip(beta_min, 0.0, 1.0))
        lo, hi = 0, int(max(d[-1] if n else 0, 1))
        while _scenario_moments(hi, d, prefix)["ScenarioFillRate"] + 1e-12 < beta:
            hi = max(hi + 1, int(1.5*hi) + 1)
        while lo < hi:
            mid = (lo + hi)//2
            if _scenario_moments(mid, d, prefix)["ScenarioFillRate"] + 1e-12 >= beta:
                hi = mid
            else:
                lo = mid + 1
        service_lb = max(service_lb, int(lo))

    candidates = np.unique(np.concatenate((np.array([service_lb], dtype=int), d[d >= service_lb]))).astype(int)
    idx = np.searchsorted(d, candidates, side="right")
    sum_le = prefix[idx]
    shortage_sum = (total - sum_le) - candidates * (n - idx)
    overstock_sum = candidates * idx - sum_le
    cycle = idx / max(n, 1)
    if total <= 0:
        fill = np.ones(len(candidates))
    else:
        fill = np.clip(1.0 - shortage_sum / total, 0.0, 1.0)
    costs = (candidates > 0).astype(float)*order_cost + unit*candidates + hold_month*(overstock_sum/n) + emergency_multiplier*unit*(shortage_sum/n)
    feasible = np.ones(len(candidates), dtype=bool)
    if alpha_min is not None:
        feasible &= cycle + 1e-12 >= float(alpha_min)
    if beta_min is not None:
        feasible &= fill + 1e-12 >= float(beta_min)
    if not np.any(feasible):
        raise RuntimeError("No feasible SAA target found")
    fidx = np.where(feasible)[0]
    # lexsort by expected cost, then smaller q for deterministic tie-breaking
    order = np.lexsort((candidates[fidx], costs[fidx]))
    j = int(fidx[order[0]])
    q = int(candidates[j])
    best = {
        "ExpectedCost": float(costs[j]),
        "ScenarioShortage": float(shortage_sum[j]/n),
        "ScenarioOverstock": float(overstock_sum[j]/n),
        "ScenarioFillRate": float(fill[j]),
        "ScenarioCycleService": float(cycle[j]),
        "ScenarioCount": int(scenario_count),
        "AlphaFloor": alpha_min,
        "BetaFloor": beta_min,
    }
    return q, best

def newsvendor_reference(fit: Fit, unit: float, hold_month: float, emergency_multiplier: float) -> int:
    """Closed-form reference for the unconstrained linear-cost model without fixed charge."""
    fractile = np.clip((emergency_multiplier * unit - unit) / (emergency_multiplier * unit + hold_month), 0, 0.999999)
    return int(fit.ppf(float(fractile)) if fractile > 0 else 0)

def mase_scale(x: np.ndarray) -> float:
    return max(float(np.mean(np.abs(np.diff(x)))), 1e-9)


def harmonic_seasonality_p(x: np.ndarray, period: int = 12) -> float:
    """Joint F-test for a 12-month harmonic component beyond a linear trend.

    This diagnostic is descriptive only. With 48 monthly observations (four
    annual cycles), the rolling temporal branch does not add a separately tuned
    seasonal parametric model; seasonal-naive remains the prospective benchmark.
    """
    y=np.asarray(x,dtype=float); n=len(y)
    if n < 8: return np.nan
    t=np.arange(n,dtype=float)
    reduced=np.column_stack([np.ones(n),t])
    full=np.column_stack([np.ones(n),t,np.sin(2*np.pi*t/period),np.cos(2*np.pi*t/period)])
    br=np.linalg.lstsq(reduced,y,rcond=None)[0]; bf=np.linalg.lstsq(full,y,rcond=None)[0]
    rssr=float(np.sum((y-reduced@br)**2)); rssf=float(np.sum((y-full@bf)**2))
    df1=2; df2=n-full.shape[1]
    if df2 <= 0 or rssf <= 0: return np.nan
    f=max(0.0,((rssr-rssf)/df1)/(rssf/df2))
    return float(stats.f.sf(f,df1,df2))


def classify_profile(x: np.ndarray) -> str:
    return "Recurrent-positive" if np.all(x > 0) else "Intermittent"


def empirical_analysis(monthly: pd.DataFrame, inputs: pd.DataFrame) -> tuple[pd.DataFrame, ...]:
    hold_month = float(inputs["h"].iloc[0]) / 12.0
    detail_rows, fit_rows, struct_rows, temporal_rows = [], [], [], []
    for med in sorted(monthly.Medication.unique()):
        series = monthly.loc[monthly.Medication == med].sort_values("MonthIndex").Demand.to_numpy(float)
        row = inputs.loc[inputs.Medication == med].iloc[0]
        slope = stats.linregress(np.arange(len(series)), series)
        acf1 = float(np.corrcoef(series[:-1], series[1:])[0, 1]) if np.std(series[:-1]) > 0 and np.std(series[1:]) > 0 else 0.0
        try: lb2=float(acorr_ljungbox(series,lags=[2],return_df=True)["lb_pvalue"].iloc[0])
        except Exception: lb2=np.nan
        season_p=harmonic_seasonality_p(series)
        struct_rows.append({"Medication": med, "Profile": classify_profile(series), "Mean": np.mean(series), "CV": np.std(series, ddof=1)/max(np.mean(series),1e-9), "ZeroShare": np.mean(series==0), "TrendSlope": slope.slope, "TrendP": slope.pvalue, "SeasonalityP": season_p, "ACF1": acf1,"LjungBoxP2":lb2})
        fullfits = fit_all(series)
        for model, fit in fullfits.items():
            if fit is not None:
                fit_rows.append({"Medication":med,"Profile":classify_profile(series),"Model":model,"AIC":fit.aic,"LogLik":fit.loglik,**{f"par_{k}":v for k,v in fit.params.items()}})
        for test_idx in range(36, 48):
            train = series[:test_idx]; actual = series[test_idx]; fits = fit_all(train)
            valid = {k:v for k,v in fits.items() if v is not None and np.isfinite(v.aic)}
            marginal_winner = min(valid, key=lambda k: valid[k].aic)
            temporal_fit, tmeta = select_temporal_scenario_model(train,marginal_winner)
            selected_code = temporal_fit.model if temporal_fit is not None else marginal_winner
            selected_label = TEMPORAL_LABELS.get(selected_code,MODEL_LABELS.get(selected_code,selected_code))
            selected_fit = temporal_fit if temporal_fit is not None else valid[marginal_winner]
            temporal_rows.append({"Medication":med,"Profile":classify_profile(train),"TestMonth":test_idx+1,"MarginalAICWinner":marginal_winner,"SelectedScenarioModel":selected_label,"SelectedScenarioCode":selected_code,**tmeta})
            scale = mase_scale(train)
            targets = {"Mean": max(0, int(round(np.mean(train)))),"Previous": max(0, int(round(train[-1]))),"SeasonalNaive": max(0, int(round(train[-12])))}
            saa_meta = {}; newsvendor_q = {}
            policy_fits={**valid}
            if temporal_fit is not None: policy_fits[selected_code]=temporal_fit
            for model, fit in policy_fits.items():
                scenario_seed = _stable_seed(med, test_idx + 1, model, "rolling-saa")
                q_diag, m_diag = two_stage_saa_target(fit,row.unit_price,row.o,hold_month,row.s_factor,scenario_count=EMPIRICAL_SAA_SCENARIOS,seed=scenario_seed)
                q95, m95 = two_stage_saa_target(fit,row.unit_price,row.o,hold_month,row.s_factor,alpha_min=0.95,beta_min=0.95,scenario_count=EMPIRICAL_SAA_SCENARIOS,seed=scenario_seed)
                q99, m99 = two_stage_saa_target(fit,row.unit_price,row.o,hold_month,row.s_factor,alpha_min=0.99,beta_min=0.99,scenario_count=EMPIRICAL_SAA_SCENARIOS,seed=scenario_seed)
                targets[f"{model}_EconomicDiagnostic"] = q_diag; targets[f"{model}_SC95"] = q95; targets[f"{model}_SC99"] = q99
                saa_meta[f"{model}_EconomicDiagnostic"] = m_diag; saa_meta[f"{model}_SC95"] = m95; saa_meta[f"{model}_SC99"] = m99
                newsvendor_q[model] = newsvendor_reference(fit,row.unit_price,hold_month,row.s_factor)
            for policy,q in targets.items():
                prefix=policy.split("_")[0] if "_" in policy else "Baseline"
                fit=policy_fits.get(prefix)
                metrics=target_cost(q,actual,row.unit_price,row.o,hold_month,row.s_factor); meta=saa_meta.get(policy,{})
                detail_rows.append({"Medication":med,"Profile":classify_profile(train),"TestMonth":test_idx+1,"ActualDemand":actual,"Policy":policy,"Model":prefix if fit else "Baseline","MarginalAICWinner":marginal_winner,"AICWinner":marginal_winner,"SelectedScenarioModel":selected_label,"SelectedScenarioCode":selected_code,"TemporalSelected":bool(temporal_fit is not None),"Q":q,**metrics,"ScenarioExpectedCost":meta.get("ExpectedCost",np.nan),"ScenarioFillRate":meta.get("ScenarioFillRate",np.nan),"ScenarioCycleService":meta.get("ScenarioCycleService",np.nan),"ScenarioCount":meta.get("ScenarioCount",np.nan),"NewsvendorReferenceQ":newsvendor_q.get(prefix,np.nan),"ForecastMAE":abs((fit.mean() if fit else q)-actual),"MASE":abs((fit.mean() if fit else q)-actual)/scale,"NegLogScore":fit.logscore(actual) if fit else np.nan})
    detail=pd.DataFrame(detail_rows); fits=pd.DataFrame(fit_rows); structure=pd.DataFrame(struct_rows); temporal=pd.DataFrame(temporal_rows)
    diagnostic=detail[detail.apply(lambda r:r.Policy==f"{r.SelectedScenarioCode}_EconomicDiagnostic",axis=1)].copy()
    sc95=detail[detail.apply(lambda r:r.Policy==f"{r.SelectedScenarioCode}_SC95",axis=1)].copy()
    sc99=detail[detail.apply(lambda r:r.Policy==f"{r.SelectedScenarioCode}_SC99",axis=1)].copy()
    base=detail[detail.Policy.isin(["Mean","Previous","SeasonalNaive"])].copy()
    selected=pd.concat([diagnostic.assign(PolicyGroup="Unconstrained economic (diagnostic)"),sc95.assign(PolicyGroup="Service-constrained 95/95"),sc99.assign(PolicyGroup="Service-constrained 99/99"),base.assign(PolicyGroup=base.Policy)],ignore_index=True)
    summary=selected.groupby("PolicyGroup",as_index=False).agg(Evaluations=("Cost","size"),MeanCostCLP=("Cost","mean"),SDCostCLP=("Cost","std"),MedianCostCLP=("Cost","median"),TotalShortage=("Shortage","sum"),TotalOverstock=("Overstock","sum"),MeanFillRate=("FillRate","mean"),CycleService=("CycleService","mean"),MAE=("ForecastMAE","mean"),MASE=("MASE","mean"))
    med_summary=selected.groupby(["Medication","Profile","PolicyGroup"],as_index=False).agg(MeanCostCLP=("Cost","mean"),SDCostCLP=("Cost","std"),MedianCostCLP=("Cost","median"),TotalShortage=("Shortage","sum"),TotalOverstock=("Overstock","sum"),MeanFillRate=("FillRate","mean"),CycleService=("CycleService","mean"),MASE=("MASE","mean"))
    return detail,fits,structure,summary,med_summary,temporal


def simulate_series(rng: np.random.Generator, dgp: str, mean: float, cv: float, zero: float, trend: float, season: float, n: int = 60) -> np.ndarray:
    t = np.arange(n); mu_t = mean * np.maximum(0.15, 1 + trend * t / max(n-1,1) + season * np.sin(2*np.pi*t/12))
    if dgp == "NO": y = rng.normal(mu_t, np.maximum(cv * mu_t, 1))
    elif dgp == "GA":
        shape = max(1/cv**2, .05); y = rng.gamma(shape, mu_t/shape)
    else:
        alpha = np.maximum(cv**2 - 1/np.maximum(mu_t,1), .001); r = 1/alpha; prob = r/(r+mu_t)
        y = rng.negative_binomial(r, prob)
        if dgp == "ZINBI":
            y[rng.random(n) < zero] = 0
        elif dgp == "HNB":
            inactive = rng.random(n) < zero
            # Draw the active state from a zero-truncated NB component.
            active = ~inactive
            while np.any(active & (y == 0)):
                redraw = active & (y == 0)
                y[redraw] = rng.negative_binomial(r[redraw], prob[redraw])
            y[inactive] = 0
    return np.maximum(np.rint(y),0).astype(float)


def simulate_cases_batch(n_cases: int, seed: int, case_offset: int = 0) -> pd.DataFrame:
    """Generate one deterministic batch of diagnostic simulation cases."""
    rng = np.random.default_rng(seed); rows=[]
    for local_case in range(1,n_cases+1):
        case = case_offset + local_case
        dgp = rng.choice(MODELS); mean=float(np.exp(rng.uniform(np.log(20),np.log(200000)))); cv=float(rng.uniform(.1,1.8)); zero=float(rng.uniform(.03,.70)) if dgp in ("ZINBI","HNB") else 0.0; trend=float(rng.uniform(-.30,.30)); season=float(rng.uniform(0,.30)); emergency=float(rng.uniform(1.2,4.0)); unit=float(np.exp(rng.uniform(np.log(10),np.log(17000)))); hold=14.32/12
        series=simulate_series(rng,dgp,mean,cv,zero,trend,season,60); train=series[:48]; future=series[48:]
        fits=fit_all_simulation(train); valid={k:v for k,v in fits.items() if v is not None and np.isfinite(v.aic)}
        aic_win=min(valid,key=lambda k:valid[k].aic); outcomes={}
        future_total=max(float(np.sum(future)),1.0)
        for model,fit in valid.items():
            q, _ = two_stage_saa_target(
                fit, unit, 20312.6514, hold, emergency,
                scenario_count=SIMULATION_SAA_SCENARIOS,
                seed=_stable_seed(case, model, "simulation-saa", base=seed),
            )
            mets=[target_cost(q,d,unit,20312.6514,hold,emergency) for d in future]
            mean_cost=float(np.mean([m["Cost"] for m in mets])); shortage=float(np.sum([m["Shortage"] for m in mets])); overstock=float(np.sum([m["Overstock"] for m in mets]))
            shortage_rate=shortage/future_total; overstock_rate=overstock/future_total; fill_rate=max(0.0,1.0-shortage_rate)
            outcomes[model]={"Cost":mean_cost,"Q":q,"Shortage":shortage,"Overstock":overstock,"ShortageRate":shortage_rate,"OverstockRate":overstock_rate,"FillRate":fill_rate}
        min_cost=min(v["Cost"] for v in outcomes.values()); tied=[m for m,v in outcomes.items() if v["Cost"] <= 1.01*min_cost]
        op_win=tied[0] if len(tied)==1 else "TIE"
        aout=outcomes[aic_win]
        rows.append({"Case":case,"DGP":dgp,"Mean":mean,"CV":cv,"ZeroProbability":zero,"Trend":trend,"Seasonality":season,"EmergencyMultiplier":emergency,"UnitCost":unit,"AICWinner":aic_win,"OperationalWinner":op_win,"Agreement":aic_win==op_win,"Tie":op_win=="TIE","MinMeanCost":min_cost,"AICCostRegretPct":100.0*(aout["Cost"]-min_cost)/max(min_cost,1e-12),"AICShortageRate":aout["ShortageRate"],"AICOverstockRate":aout["OverstockRate"],"AICFillRate":aout["FillRate"],**{f"Cost_{m}":outcomes.get(m,{}).get("Cost",np.nan) for m in MODELS},**{f"Q_{m}":outcomes.get(m,{}).get("Q",np.nan) for m in MODELS},**{f"Shortage_{m}":outcomes.get(m,{}).get("Shortage",np.nan) for m in MODELS},**{f"Overstock_{m}":outcomes.get(m,{}).get("Overstock",np.nan) for m in MODELS},**{f"ShortageRate_{m}":outcomes.get(m,{}).get("ShortageRate",np.nan) for m in MODELS},**{f"OverstockRate_{m}":outcomes.get(m,{}).get("OverstockRate",np.nan) for m in MODELS},**{f"FillRate_{m}":outcomes.get(m,{}).get("FillRate",np.nan) for m in MODELS}})
    return pd.DataFrame(rows)


def summarize_simulation(cases: pd.DataFrame, seed: int = SEED) -> tuple[pd.DataFrame,pd.DataFrame]:
    summary=pd.DataFrame({"Metric":[
        "Simulation cases","SAA scenarios per candidate fit","Future evaluation periods per case",
        "Operational ties (within 1%)","Unique operational winners","AIC/operational agreement among unique winners",
        "Mean AIC-selected cost regret (%)","Median AIC-selected cost regret (%)",
        "Mean AIC-selected shortage rate","Mean AIC-selected overstock rate","Mean AIC-selected fill rate"],
        "Value":[len(cases),SIMULATION_SAA_SCENARIOS,12,int(cases.Tie.sum()),int((~cases.Tie).sum()),float(cases.loc[~cases.Tie,"Agreement"].mean()),
                 float(cases.AICCostRegretPct.mean()),float(cases.AICCostRegretPct.median()),float(cases.AICShortageRate.mean()),float(cases.AICOverstockRate.mean()),float(cases.AICFillRate.mean())]})
    unique=cases[~cases.Tie].copy(); features=["Mean","CV","ZeroProbability","Trend","Seasonality","EmergencyMultiplier","UnitCost"]
    counts=unique.OperationalWinner.value_counts(); eligible=counts[counts>=5].index
    tree_data=unique[unique.OperationalWinner.isin(eligible)].copy()
    X_dev,X_test,y_dev,y_test=train_test_split(tree_data[features],tree_data.OperationalWinner,test_size=.30,random_state=seed,stratify=tree_data.OperationalWinner)
    X_train,X_val,y_train,y_val=train_test_split(X_dev,y_dev,test_size=.25,random_state=seed+1,stratify=y_dev)
    best=None
    for depth in [2,3,4,5,6]:
        for leaf in [8,15,25,40]:
            clf=DecisionTreeClassifier(max_depth=depth,min_samples_leaf=leaf,class_weight="balanced",random_state=seed)
            clf.fit(X_train,y_train); val_pred=clf.predict(X_val); score=balanced_accuracy_score(y_val,val_pred)
            if best is None or score>best[0]: best=(score,depth,leaf)
    _,depth,leaf=best
    clf=DecisionTreeClassifier(max_depth=depth,min_samples_leaf=leaf,class_weight="balanced",random_state=seed)
    clf.fit(X_dev,y_dev); pred=clf.predict(X_test)
    metrics=pd.DataFrame([{"DevelopmentN":len(X_dev),"TestN":len(X_test),"MaxDepth":depth,"MinLeaf":leaf,"TestAccuracy":accuracy_score(y_test,pred),"TestBalancedAccuracy":balanced_accuracy_score(y_test,pred),"RareWinnerCasesExcluded":int(len(unique)-len(tree_data))}])
    metrics.attrs["tree"]=clf; metrics.attrs["X_test"]=X_test; metrics.attrs["y_test"]=y_test; metrics.attrs["pred"]=pred; metrics.attrs["features"]=features
    return summary,metrics


def load_simulation_batches(expected_cases: int) -> pd.DataFrame:
    files=sorted(OUT_DATA.glob("_simulation_batch_*.csv"))
    if not files:
        raise FileNotFoundError("No simulation batch files found. Run code/run_revision.py.")
    cases=pd.concat([pd.read_csv(f) for f in files],ignore_index=True).sort_values("Case").reset_index(drop=True)
    if len(cases)!=expected_cases or cases.Case.nunique()!=expected_cases:
        raise AssertionError(f"Expected {expected_cases} unique simulation cases; found {len(cases)} rows/{cases.Case.nunique()} unique")
    return cases

def escape_tex(s: object) -> str:
    return str(s).replace("%","\\%").replace("_","\\_").replace("&","\\&")


def write_tex_table(df: pd.DataFrame, path: Path, caption: str, label: str, formats: Optional[Dict[str,str]]=None, note: str="") -> None:
    formats=formats or {}; cols=list(df.columns); align="l"+"r"*(len(cols)-1)
    lines=["\\begin{table}[H]","\\centering","\\scriptsize",f"\\caption{{{caption}}}",f"\\label{{{label}}}","\\resizebox{\\textwidth}{!}{%",f"\\begin{{tabular}}{{{align}}}","\\toprule"," & ".join(escape_tex(c) for c in cols)+" \\\\","\\midrule"]
    for _,row in df.iterrows():
        vals=[]
        for c in cols:
            v=row[c]
            if pd.isna(v): out="--"
            elif c in formats: out=formats[c].format(v)
            elif isinstance(v,(float,np.floating)): out=f"{v:.3f}"
            else: out=str(v)
            vals.append(escape_tex(out))
        lines.append(" & ".join(vals)+" \\\\")
    lines += ["\\bottomrule","\\end{tabular}%","}"]
    if note: lines.append(f"\\begin{{flushleft}}\\footnotesize Note: {note}\\end{{flushleft}}")
    lines.append("\\end{table}")
    path.write_text("\n".join(lines)+"\n",encoding="utf-8")


def build_tables(monthly,inputs,detail,fits,structure,summary,med_summary,cases,sim_summary,tree_metrics):
    params=inputs[["Medication","o","h","s_factor","C_money","unit_price","stock_initial","q_real"]].copy(); params["h_month"]=params.h/12; params=params[["Medication","unit_price","o","h","h_month","s_factor","C_money","stock_initial","q_real"]]
    params.columns=["Medicine","Unit cost (CLP)","Order cost (CLP)","Holding/year","Holding/month","Emergency multiplier","Historical capacity (CLP)","Dec. initial stock","Dec. observed Q"]
    write_tex_table(params,OUT_TABLES/"table_parameters.tex","Transparent medicine-level operational inputs. Values are in 2023 Chilean pesos (CLP).","tab:parameters",{"Unit cost (CLP)":"{:,.0f}","Order cost (CLP)":"{:,.0f}","Holding/year":"{:.2f}","Holding/month":"{:.4f}","Emergency multiplier":"{:.4f}","Historical capacity (CLP)":"{:,.0f}","Dec. initial stock":"{:,.0f}","Dec. observed Q":"{:,.0f}"},"The annual holding cost of CLP 14.32 per unit is converted to CLP 1.1933 per unit-month. The emergency multiplier 1.8714 represents ordinary acquisition plus the 87.14\\% alternative-procurement premium. December 2023 initial stock, observed Q, and historical monetary-capacity fields are retained for source documentation only and are not used as longitudinal constraints.")
    desc=structure.copy(); desc.columns=["Medicine","Demand category","Mean","CV","Zero share","Monthly trend","Trend p","Annual harmonic p","Lag-1 correlation","Ljung--Box p (lag 2)"]
    write_tex_table(desc,OUT_TABLES/"table_profiles.tex","Observed requested-demand profiles over 48 months.","tab:profiles",{"Mean":"{:,.1f}","CV":"{:.3f}","Zero share":"{:.3f}","Monthly trend":"{:,.2f}","Trend p":"{:.3f}","Annual harmonic p":"{:.3f}","Lag-1 correlation":"{:.3f}","Ljung--Box p (lag 2)":"{:.3f}"},"Annual harmonic p is the joint F-test for 12-month sine/cosine terms after a linear time trend; it is descriptive because only four annual cycles are available. Seasonal-naive remains the prospective seasonal benchmark.")
    pivot=fits.pivot(index=["Medication","Profile"],columns="Model",values="AIC").reset_index(); pivot.columns.name=None
    def tieaware(row):
        vals={m:row.get(m,np.nan) for m in MODELS if pd.notna(row.get(m,np.nan))}; best=min(vals.values()); near=[m for m,v in vals.items() if abs(v-best)<0.01]
        return "/".join(near)+(" tie" if len(near)>1 else "")
    pivot["Winner"]=pivot.apply(tieaware,axis=1); pivot=pivot.rename(columns={"Medication":"Medicine","Profile":"Demand category"})
    write_tex_table(pivot,OUT_TABLES/"table_fit.tex","Full-series distributional comparison by AIC.","tab:fit",{m:"{:.1f}" for m in MODELS},"Abbreviations: NO = Normal; GA = Gamma; NBII = negative binomial type II; ZINBI = zero-inflated NBII; HNB = hurdle negative binomial. Gamma is not applicable when the calibration series contains zeros. When the two lowest AIC values differ by less than 0.01, the result is reported as a numerical AIC tie rather than assigning an arbitrary winner. ZINBI and HNB are alternative zero-aware parameterizations and are not interpreted causally.")
    policy_order=["Service-constrained 95/95","Service-constrained 99/99","Unconstrained economic (diagnostic)","Mean","Previous","SeasonalNaive"]
    sumshow=summary.set_index("PolicyGroup").loc[policy_order].reset_index(); sumshow.columns=["Prospective policy","n","Mean cost (CLP)","SD cost (CLP)","Median cost (CLP)","Shortage units","Overstock units","Mean fill rate","Cycle service","MAE","MASE"]
    roles={"Service-constrained 95/95":"Primary service scenario","Service-constrained 99/99":"High-availability scenario","Unconstrained economic (diagnostic)":"Diagnostic only","Mean":"Naive benchmark","Previous":"Naive benchmark","SeasonalNaive":"Naive benchmark"}
    sumshow.insert(1,"Role",sumshow["Prospective policy"].map(roles))
    write_tex_table(sumshow,OUT_TABLES/"table_rolling_summary.tex","Twelve-month rolling-origin evaluation (156 medicine-month decisions per policy).","tab:rolling",{"Mean cost (CLP)":"{:,.0f}","SD cost (CLP)":"{:,.0f}","Median cost (CLP)":"{:,.0f}","Shortage units":"{:,.0f}","Overstock units":"{:,.0f}","Mean fill rate":"{:.3f}","Cycle service":"{:.3f}","MAE":"{:,.1f}","MASE":"{:.3f}"},"At each origin only earlier months are used. Five marginal families are first compared by AIC. When the training window shows temporal structure and a Gaussian conditional response is eligible, a time-trend GLM and GARMA(1,0)/(2,0) candidates compete by AICc; a temporal model replaces the marginal generator only when it improves AICc by at least 2 relative to static Gaussian. The selected scenario model then feeds the two-stage SAA. SC95 and SC99 impose 95/95 and 99/99 scenario-based cycle-service/fill-rate floors; the unconstrained program is diagnostic only.")
    meds=med_summary[med_summary.PolicyGroup.isin(["Unconstrained economic (diagnostic)","Service-constrained 95/95","Service-constrained 99/99"])].copy(); meds["PolicyGroup"]=meds.PolicyGroup.replace({"Unconstrained economic (diagnostic)":"Diagnostic","Service-constrained 95/95":"SC95","Service-constrained 99/99":"SC99"})
    wide0=meds.pivot(index=["Medication","Profile"],columns="PolicyGroup",values=["MeanCostCLP","MeanFillRate","CycleService"])
    wide0=wide0[[
        ("MeanCostCLP","SC95"),("MeanCostCLP","SC99"),("MeanCostCLP","Diagnostic"),
        ("MeanFillRate","SC95"),("MeanFillRate","SC99"),("MeanFillRate","Diagnostic"),
        ("CycleService","SC95"),("CycleService","SC99"),("CycleService","Diagnostic")]]
    wide=wide0.reset_index()
    wide.columns=["Medicine","Profile","SC95 cost","SC99 cost","Diagnostic cost","SC95 fill","SC99 fill","Diagnostic fill","SC95 cycle","SC99 cycle","Diagnostic cycle"]
    write_tex_table(wide,OUT_TABLES/"table_rolling_medicine.tex","Medicine-level rolling-origin cost and service outcomes.","tab:rollingmedicine",{"Diagnostic cost":"{:,.0f}","SC95 cost":"{:,.0f}","SC99 cost":"{:,.0f}","Diagnostic fill":"{:.3f}","SC95 fill":"{:.3f}","SC99 fill":"{:.3f}","Diagnostic cycle":"{:.3f}","SC95 cycle":"{:.3f}","SC99 cycle":"{:.3f}"},"SC95 and SC99 solve the same two-stage sample-average program subject to explicit scenario-based service floors. The unconstrained two-stage program is retained only as a diagnostic comparator. Costs are mean realized CLP per medicine-month.")
    sim_display=sim_summary.copy()
    def fmt_sim(r):
        m=str(r["Metric"]); v=float(r["Value"])
        if m in {"Simulation cases","SAA scenarios per candidate fit","Future evaluation periods per case","Operational ties (within 1%)","Unique operational winners"}: return f"{int(round(v)):,}"
        if "regret (%)" in m: return f"{v:.2f}%"
        if "rate" in m: return f"{v:.3f}"
        return f"{v:.3f}"
    sim_display["Value"]=[fmt_sim(r) for _,r in sim_display.iterrows()]
    write_tex_table(sim_display,OUT_TABLES/"table_simulation_summary.tex","Randomized simulation design, statistical--operational agreement, and diagnostic operational consequences.","tab:simsum",{},"Each of the 900 randomized cases fits the eligible marginal candidates on 48 periods, generates 256 SAA demand scenarios per candidate fit, and evaluates the resulting unconstrained two-stage target over 12 new periods. Operational ties are declared when all models within the tied set are no more than 1\\% above the minimum 12-period mean cost. AIC-selected cost regret is relative to the minimum fitted-model cost in the same case; shortage and overstock rates are normalized by total future demand. These diagnostic simulation outcomes are not service-qualified hospital policies.")
    tm=tree_metrics.copy(); tm.columns=["Development n","Test n","Depth","Minimum leaf","Test accuracy","Balanced accuracy","Rare winner cases excluded"]
    write_tex_table(tm,OUT_TABLES/"table_tree_metrics.tex","Independent-test performance of the exploratory decision tree.","tab:tree",{"Test accuracy":"{:.3f}","Balanced accuracy":"{:.3f}"},"Depth and minimum leaf size are selected using development data only; the held-out test set is not used for tuning.")
    for name,df in [("parameters",params),("profiles",structure),("rolling_detail",detail),("rolling_summary",summary),("rolling_medicine",med_summary),("fit_full",fits),("simulation_cases",cases),("simulation_summary",sim_summary),("tree_metrics",tree_metrics)]:
        df.to_csv(OUT_DATA/f"{name}.csv",index=False)


def build_figures(monthly, detail, fits, summary, cases, tree_metrics):
    sns.set_theme(style="whitegrid",context="paper")
    # Figure 1: compact workflow.
    fig,ax=plt.subplots(figsize=(11,4)); ax.axis("off")
    labels=["48 months of\nrequested demand","Rolling origins\nmonths 37--48","Marginal models +\ntemporal diagnostics","Conditional GLM/GARMA\nscenario generator","Two-stage SAA\nSC95 and SC99","Cost, service,\nand calibration"]
    xs=np.linspace(.08,.92,len(labels))
    for i,(x,lbl) in enumerate(zip(xs,labels)):
        ax.text(x,.55,lbl,ha="center",va="center",fontsize=10,weight="bold",bbox=dict(boxstyle="round,pad=.55",fc="#E8F1FA",ec="#24527A",lw=1.5))
        if i<len(labels)-1: ax.annotate("",xy=(xs[i+1]-.085,.55),xytext=(x+.085,.55),arrowprops=dict(arrowstyle="->",lw=1.7,color="#24527A"))
    ax.text(.50,.15,"Parallel randomized simulation: 900 cases × 12 prospective periods; development/test tree validation",ha="center",fontsize=10,bbox=dict(boxstyle="round,pad=.45",fc="#F8EBDD",ec="#B5651D"))
    fig.tight_layout(); fig.savefig(OUT_FIGURES/"fig1_revised_workflow.pdf",bbox_inches="tight"); fig.savefig(OUT_FIGURES/"fig1_revised_workflow.png",dpi=320,bbox_inches="tight"); plt.close(fig)
    # Figure 2: all demand series.
    fig,axes=plt.subplots(4,4,figsize=(12,9),sharex=True); axes=axes.ravel()
    for ax,med in zip(axes,sorted(monthly.Medication.unique())):
        d=monthly[monthly.Medication==med]; ax.plot(d.MonthIndex,d.Demand,color="#24527A",lw=1.3); ax.axvspan(37,48,color="#F59E0B",alpha=.12); ax.set_title(med,fontsize=9); ax.tick_params(labelsize=7)
    for ax in axes[len(monthly.Medication.unique()):]: ax.axis("off")
    fig.supxlabel("Month index"); fig.supylabel("Requested demand (units)"); fig.tight_layout(); fig.savefig(OUT_FIGURES/"fig2_demand_profiles.pdf",bbox_inches="tight"); fig.savefig(OUT_FIGURES/"fig2_demand_profiles.png",dpi=320,bbox_inches="tight"); plt.close(fig)
    # Figure 3: representative recurrent-positive and intermittent fits.
    fig,axes=plt.subplots(1,2,figsize=(11,4.3))
    for ax,med in zip(axes,["M03","M13"]):
        x=monthly.loc[monthly.Medication==med,"Demand"].to_numpy(float); fs=fit_all(x); xmax=int(max(np.max(x)*1.15,10)); grid=np.arange(0,xmax+1)
        ax.hist(x,bins=min(12,max(6,int(np.sqrt(len(x))))),density=True,alpha=.28,color="#64748B",label="Observed")
        for m in MODELS:
            f=fs[m]
            if f is None: continue
            if m in ("NO","GA"):
                xx=np.linspace(0,xmax,400); ax.plot(xx,f.pmf_or_pdf(xx),lw=1.7,label=MODEL_LABELS[m],color=MODEL_COLORS[m])
            else:
                step=max(1,xmax//500); xx=grid[::step]; ax.plot(xx,f.pmf_or_pdf(xx),lw=1.4,label=MODEL_LABELS[m],color=MODEL_COLORS[m])
        ax.set_title(f"{med}: {'recurrent-positive' if np.all(x>0) else 'intermittent'} demand"); ax.set_xlabel("Monthly requested demand"); ax.set_ylabel("Density / probability"); ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(OUT_FIGURES/"fig3_fitted_distributions.pdf",bbox_inches="tight"); fig.savefig(OUT_FIGURES/"fig3_fitted_distributions.png",dpi=320,bbox_inches="tight"); plt.close(fig)
    # Figure 4: cost-service trade-off.
    order=["Service-constrained 95/95","Service-constrained 99/99","Unconstrained economic (diagnostic)"]
    s=summary.set_index("PolicyGroup").loc[order].reset_index(); fig,axes=plt.subplots(1,2,figsize=(11,4.2)); colors=["#4C956C","#2C6E49","#9CA3AF"]
    axes[0].barh(s.PolicyGroup,s.MeanCostCLP,color=colors); axes[0].set_xlabel("Mean realized cost (CLP)"); axes[0].invert_yaxis(); axes[0].ticklabel_format(axis='x',style='sci',scilimits=(6,6))
    axes[1].scatter(s.MeanFillRate,s.CycleService,s=75,c=colors)
    for _,r in s.iterrows(): axes[1].annotate(r.PolicyGroup,(r.MeanFillRate,r.CycleService),xytext=(4,3),textcoords="offset points",fontsize=7)
    axes[1].axvline(.95,ls="--",lw=.8,color="#6B7280"); axes[1].axhline(.95,ls="--",lw=.8,color="#6B7280")
    axes[1].set_xlabel("Mean fill rate"); axes[1].set_ylabel("Realized cycle service"); axes[1].set_xlim(.74,1.01); axes[1].set_ylim(.40,1.01); fig.tight_layout(); fig.savefig(OUT_FIGURES/"fig4_rolling_tradeoff.pdf",bbox_inches="tight"); fig.savefig(OUT_FIGURES/"fig4_rolling_tradeoff.png",dpi=320,bbox_inches="tight"); plt.close(fig)
    # Figure 5: operational winners by intermittency tercile.
    c=cases.copy(); c["Zero group"]=pd.cut(c.ZeroProbability,[-.001,.233,.466,.701],labels=["Low","Moderate","High"]); tab=pd.crosstab(c["Zero group"],c.OperationalWinner,normalize="index").reindex(columns=list(MODELS)+["TIE"],fill_value=0)
    fig,ax=plt.subplots(figsize=(8,4.3)); bottom=np.zeros(len(tab))
    for m in tab.columns:
        ax.bar(tab.index,tab[m],bottom=bottom,label=MODEL_LABELS.get(m,m),color=MODEL_COLORS[m]); bottom+=tab[m].to_numpy()
    ax.set_ylabel("Proportion of simulation cases"); ax.set_xlabel("Randomized zero-demand probability"); ax.legend(ncol=3,fontsize=8,loc="upper center",bbox_to_anchor=(.5,1.20)); fig.tight_layout(); fig.savefig(OUT_FIGURES/"fig5_simulation_operational_winners.pdf",bbox_inches="tight"); fig.savefig(OUT_FIGURES/"fig5_simulation_operational_winners.png",dpi=320,bbox_inches="tight"); plt.close(fig)
    # Figure 6: independently tested tree, enlarged for manuscript readability.
    clf=tree_metrics.attrs["tree"]; features=tree_metrics.attrs["features"]
    class_names=[MODEL_LABELS.get(c,c) for c in clf.classes_]
    fig,ax=plt.subplots(figsize=(10.5,5.2)); plot_tree(clf,feature_names=features,class_names=class_names,filled=True,rounded=True,proportion=True,impurity=False,fontsize=11,ax=ax); fig.tight_layout(pad=.2); fig.savefig(OUT_FIGURES/"fig6_decision_tree.pdf",bbox_inches="tight"); fig.savefig(OUT_FIGURES/"fig6_decision_tree.png",dpi=360,bbox_inches="tight"); plt.close(fig)
    # Figure 7: AIC winner versus operational winner, with full display labels.
    labels=list(MODELS)+["TIE"]; cm=pd.crosstab(cases.AICWinner,cases.OperationalWinner).reindex(index=MODELS,columns=labels,fill_value=0)
    cm.index=[MODEL_LABELS.get(x,x) for x in cm.index]; cm.columns=[MODEL_LABELS.get(x,"Tie" if x=="TIE" else x) for x in cm.columns]
    fig,ax=plt.subplots(figsize=(9.2,5.4)); sns.heatmap(cm,annot=True,fmt="d",cmap="Blues",ax=ax,cbar_kws={"label":"Cases"},annot_kws={"fontsize":9}); ax.set_xlabel("Operational winner in diagnostic cost simulation"); ax.set_ylabel("AIC winner"); ax.tick_params(axis='x',rotation=25); fig.tight_layout(); fig.savefig(OUT_FIGURES/"fig7_fit_operational_matrix.pdf",bbox_inches="tight"); fig.savefig(OUT_FIGURES/"fig7_fit_operational_matrix.png",dpi=360,bbox_inches="tight"); plt.close(fig)


def _write_manifest(seed: int, simulation_cases: int) -> None:
    manifest={"seed":seed,"simulation_cases":simulation_cases,"simulation_batch_size":75,"rolling_origins":12,"medicine_month_evaluations":156,"demand_definition":"monthly requested demand","annual_holding_cost_clp":14.32,"monthly_holding_cost_clp":14.32/12,"emergency_procurement_multiplier":1.8714,"stochastic_program":{"structure":"two-stage sample-average approximation","first_stage":"regular-procurement quantity q","second_stage":"scenario shortage and overstock recourse","empirical_scenarios_per_fit":EMPIRICAL_SAA_SCENARIOS,"simulation_scenarios_per_fit":SIMULATION_SAA_SCENARIOS,"newsvendor_role":"closed-form unconstrained reference only","temporal_branch":{"screen":"training-window trend p<0.10; GARMA AR terms only with lag-2 Ljung-Box p<0.10 after detrending (or raw when no trend)","eligibility":"recurrent-positive or marginal-AIC Normal","candidates":"Gaussian GLM/time trend and GARMA(1,0)/(2,0), identity link, q=0","selection":"AICc on common conditional sample; >=2 improvement over static Gaussian","role":"conditional one-step scenario generator before two-stage SAA"}},"service_constraints":{"SC95":{"scenario_cycle_service_floor":0.95,"scenario_fill_rate_floor":0.95},"SC99":{"scenario_cycle_service_floor":0.99,"scenario_fill_rate_floor":0.99},"unconstrained_two_stage_role":"diagnostic only"},"empirical_seasonality_diagnostic":"12-month sine/cosine harmonic joint F-test beyond a linear trend; descriptive only because 48 months provide four annual cycles; seasonal-naive is the prospective benchmark","simulation_role":"diagnostic unconstrained two-stage cost-loss comparison used to study fit-operation divergence","simulation_estimation":"empirical rolling fits use the full multi-start estimators; randomized stress-test NBII/ZINBI/hurdle fits use bounded deterministic likelihood routines for numerical stability in extreme synthetic cases","generated_files":sorted(str(p.relative_to(ROOT)) for folder in (OUT_DATA,OUT_TABLES,OUT_FIGURES) for p in folder.glob("*") if not p.name.startswith("_"))}
    (OUT_DATA/"analysis_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--stage",choices=["empirical","simulation-batch","assemble"],required=True)
    parser.add_argument("--simulation-cases",type=int,default=900)
    parser.add_argument("--seed",type=int,default=SEED)
    parser.add_argument("--batch-index",type=int,default=None)
    parser.add_argument("--batch-size",type=int,default=75)
    args=parser.parse_args()

    if args.stage=="simulation-batch":
        if args.batch_index is None: raise SystemExit("--batch-index is required for simulation-batch")
        offset=args.batch_index*args.batch_size
        n=max(0,min(args.batch_size,args.simulation_cases-offset))
        if n<=0: raise SystemExit("Requested simulation batch is outside the case range")
        bseed=int((args.seed+100003*args.batch_index)%(2**32-1))
        df=simulate_cases_batch(n,bseed,case_offset=offset)
        out=OUT_DATA/f"_simulation_batch_{args.batch_index:02d}.csv"; df.to_csv(out,index=False)
        return

    monthly=pd.read_csv(SOURCE/"monthly_demand_long.csv"); inputs=pd.read_csv(SOURCE/"empirical_inputs.csv")
    if args.stage=="empirical":
        detail,fits,structure,summary,med_summary,temporal=empirical_analysis(monthly,inputs)
        for name,df in [("detail",detail),("fits",fits),("structure",structure),("summary",summary),("med_summary",med_summary),("temporal",temporal)]:
            df.to_csv(OUT_DATA/f"_emp_{name}.csv",index=False)
        return

    # assemble
    needed=[OUT_DATA/f"_emp_{x}.csv" for x in ["detail","fits","structure","summary","med_summary","temporal"]]
    if not all(x.exists() for x in needed): raise FileNotFoundError("Empirical stage outputs are missing. Run code/run_revision.py.")
    detail=pd.read_csv(needed[0]); fits=pd.read_csv(needed[1]); structure=pd.read_csv(needed[2]); summary=pd.read_csv(needed[3]); med_summary=pd.read_csv(needed[4]); temporal=pd.read_csv(needed[5])
    cases=load_simulation_batches(args.simulation_cases); sim_summary,tree_metrics=summarize_simulation(cases,args.seed)
    build_tables(monthly,inputs,detail,fits,structure,summary,med_summary,cases,sim_summary,tree_metrics)
    temporal.to_csv(OUT_DATA/"temporal_selection.csv",index=False)
    build_figures(monthly,detail,fits,summary,cases,tree_metrics)
    _write_manifest(args.seed,args.simulation_cases)
    for f in list(OUT_DATA.glob("_emp_*.csv"))+list(OUT_DATA.glob("_simulation_batch_*.csv")):
        try: f.unlink()
        except FileNotFoundError: pass
    print(json.dumps({"rolling":summary.to_dict(orient="records"),"simulation":sim_summary.to_dict(orient="records"),"tree":tree_metrics.to_dict(orient="records")},indent=2))


if __name__=="__main__": main()
