#!/usr/bin/env python3
"""Prospective calibration of marginal versus temporal-adaptive scenarios.

For each of the 156 rolling origins, the script evaluates (i) the minimum-AIC
marginal model and (ii) the prespecified scenario model used by the operational
framework. The latter replaces the marginal model with a conditional Gaussian
GLM/GARMA scenario generator only when temporal screening and AICc support that
branch. All decisions use the training window only.
"""
from pathlib import Path
import importlib.util,sys,json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'data'/'revised'; SOURCE=ROOT/'data'/'source_zenodo'; ANALYSIS=ROOT/'code'/'01_revision_analysis.py'
spec=importlib.util.spec_from_file_location('revision_analysis',ANALYSIS); mod=importlib.util.module_from_spec(spec);sys.modules['revision_analysis']=mod;spec.loader.exec_module(mod)
monthly=pd.read_csv(SOURCE/'monthly_demand_long.csv')
rows=[]
for med in sorted(monthly.Medication.unique()):
    series=monthly.loc[monthly.Medication==med].sort_values('MonthIndex').Demand.to_numpy(float); full_profile=mod.classify_profile(series)
    for test_idx in range(36,48):
        train=series[:test_idx];actual=float(series[test_idx]);fits=mod.fit_all(train);valid={k:v for k,v in fits.items() if v is not None and np.isfinite(v.aic)}
        winner=min(valid,key=lambda k:valid[k].aic); marginal=valid[winner]
        temporal,tmeta=mod.select_temporal_scenario_model(train,winner); selected=temporal if temporal is not None else marginal
        def qs(f): return float(f.ppf(.05)),float(f.ppf(.50)),float(f.ppf(.95))
        m05,m50,m95=qs(marginal);h05,h50,h95=qs(selected)
        rows.append({'Medication':med,'Profile':full_profile,'TestMonth':test_idx+1,'ActualDemand':actual,'MarginalAICWinner':winner,'SelectedScenarioCode':selected.model,'SelectedScenarioModel':mod.TEMPORAL_LABELS.get(selected.model,mod.MODEL_LABELS.get(selected.model,selected.model)),'TemporalSelected':bool(temporal is not None),'TemporalSignal':bool(tmeta.get('TemporalSignal',False)),'GaussianTemporalEligible':bool(tmeta.get('GaussianTemporalEligible',False)),'LjungBoxP2':tmeta['LjungBoxP2'],'TrendP':tmeta['TrendP'],
                     'MarginalP05':m05,'MarginalP50':m50,'MarginalP95':m95,'MarginalCovered90':float(m05<=actual<=m95),'MarginalBelowP05':float(actual<m05),'MarginalAboveP95':float(actual>m95),'MarginalWidth90':m95-m05,
                     'HybridP05':h05,'HybridP50':h50,'HybridP95':h95,'HybridCovered90':float(h05<=actual<=h95),'HybridBelowP05':float(actual<h05),'HybridAboveP95':float(actual>h95),'HybridWidth90':h95-h05,
                     'MarginalMeanError':abs(float(marginal.mean())-actual),'HybridMeanError':abs(float(selected.mean())-actual)})
detail=pd.DataFrame(rows);detail.to_csv(DATA/'scenario_accuracy_detail.csv',index=False)

def summarize(label,x):
    return {'Group':label,'N':len(x),'MarginalCoverage90':x.MarginalCovered90.mean(),'HybridCoverage90':x.HybridCovered90.mean(),'MarginalAboveP95':x.MarginalAboveP95.mean(),'HybridAboveP95':x.HybridAboveP95.mean(),'MarginalBelowP05':x.MarginalBelowP05.mean(),'HybridBelowP05':x.HybridBelowP05.mean(),'MarginalMAE':x.MarginalMeanError.mean(),'HybridMAE':x.HybridMeanError.mean(),'TemporalOrigins':int(x.TemporalSelected.sum())}
summary=[summarize('Overall',detail)]
for g,x in detail.groupby('Profile'):summary.append(summarize(g,x))
summary.append(summarize('Temporal-branch origins only',detail[detail.TemporalSelected]))
summary_df=pd.DataFrame(summary);summary_df.to_csv(DATA/'scenario_accuracy_summary.csv',index=False)

tsel=detail[detail.TemporalSelected].groupby(['Medication','Profile'],as_index=False).agg(Origins=('TestMonth','size'),MarginalCoverage90=('MarginalCovered90','mean'),HybridCoverage90=('HybridCovered90','mean'),MarginalAboveP95=('MarginalAboveP95','mean'),HybridAboveP95=('HybridAboveP95','mean'),MarginalMAE=('MarginalMeanError','mean'),HybridMAE=('HybridMeanError','mean'))
tsel.to_csv(DATA/'temporal_calibration_by_medicine.csv',index=False)

rolling=pd.read_csv(DATA/'rolling_detail.csv');cost_rows=[]
for label,suffix in [('SC95','SC95'),('SC99','SC99')]:
    x=rolling[rolling.apply(lambda r:r.Policy==f"{r.SelectedScenarioCode}_{suffix}",axis=1)].copy();err=x.ScenarioExpectedCost-x.Cost;rel=err/x.Cost.replace(0,np.nan)
    cost_rows.append({'Policy':label,'N':len(x),'MeanExpectedCostCLP':x.ScenarioExpectedCost.mean(),'MeanRealizedCostCLP':x.Cost.mean(),'MeanSignedErrorCLP':err.mean(),'MeanRelativeError':rel.mean(),'MeanAbsolutePercentageError':rel.abs().mean(),'CorrelationExpectedRealized':x[['ScenarioExpectedCost','Cost']].corr().iloc[0,1],'Within10Percent':(rel.abs()<=.10).mean(),'Within20Percent':(rel.abs()<=.20).mean()})
cost_df=pd.DataFrame(cost_rows);cost_df.to_csv(DATA/'scenario_cost_accuracy.csv',index=False)

# manuscript table
cal=summary_df[summary_df.Group.isin(['Overall','Intermittent','Recurrent-positive','Temporal-branch origins only'])]
lines=[r'\begin{table}[H]',r'\centering',r'\scriptsize',r'\caption{Prospective calibration before and after conditional temporal scenario modelling.}',r'\label{tab:scenariocalibration}',r'\textbf{Panel A. Central 90\% predictive-interval calibration}\\[2pt]',r'\resizebox{\textwidth}{!}{%',r'\begin{tabular}{lrrrrr}',r'\toprule','Group & n & Marginal AIC coverage & Temporal-adaptive coverage & Marginal $>P95$ & Adaptive $>P95$ \\\\',r'\midrule']
for _,r in cal.iterrows(): lines.append(f"{r['Group']} & {int(r['N'])} & {r['MarginalCoverage90']:.3f} & {r['HybridCoverage90']:.3f} & {r['MarginalAboveP95']:.3f} & {r['HybridAboveP95']:.3f} \\\\")
lines += [r'\bottomrule',r'\end{tabular}%',r'}',r'\par\medskip',r'\textbf{Panel B. Scenario-expected versus realized cost after temporal adaptation}\\[2pt]',r'\begin{tabular}{lrrrr}',r'\toprule','Policy & n & MAPE & Correlation & Within $\pm10\%$ \\\\',r'\midrule']
for _,r in cost_df.iterrows(): lines.append(f"{r['Policy']} & {int(r['N'])} & {r['MeanAbsolutePercentageError']:.3f} & {r['CorrelationExpectedRealized']:.3f} & {r['Within10Percent']:.3f} \\\\")
lines += [r'\bottomrule',r'\end{tabular}',r'''\begin{flushleft}\footnotesize Note: ``Marginal AIC'' selects among Normal, Gamma, NBII, ZINBI, and hurdle-NB using only the training window. The temporal-adaptive framework invokes a Gaussian conditional branch only when temporal screening is positive and the response is eligible; a time-trend GLM and GARMA(1,0)/(2,0) candidates then compete by AICc. The branch must improve AICc by at least 2 relative to the static Gaussian model. This design extends the GLM--GARMA scenario comparison of Rojas et al. (2019) to rolling hospital-pharmacy decisions and service-constrained two-stage SAA.\end{flushleft}''',r'\end{table}']
(ROOT/'tables'/'revised'/'table_scenario_accuracy.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')

# temporal-selection table
sel=pd.read_csv(DATA/'temporal_selection.csv') if (DATA/'temporal_selection.csv').exists() else None
if sel is not None:
    use=sel[sel.TemporalSelected==True].copy(); counts=use.groupby(['Medication','SelectedScenarioModel']).size().unstack(fill_value=0)
    meds=tsel.set_index('Medication')
    signal_n=int(sel.TemporalSignal.sum()); eligible_n=int(sel.GaussianTemporalEligible.sum()); selected_n=int(sel.TemporalSelected.sum())
    lines=[r'\begin{table}[H]',r'\centering',r'\scriptsize',r'\caption{Selected temporal scenario models and their prospective calibration.}',r'\label{tab:temporal}',r'\resizebox{\textwidth}{!}{%',r'\begin{tabular}{lrrrrrr}',r'\toprule','Medicine & Selected temporal origins & GLM-trend & GARMA origins & Marginal coverage & Adaptive coverage & Adaptive MAE \\\\',r'\midrule']
    for med in counts.index:
        n=int(counts.loc[med].sum());glm=int(counts.loc[med].get('Gaussian GLM + trend',0));garma=n-glm;rr=meds.loc[med]
        lines.append(f"{med} & {n} & {glm} & {garma} & {rr['MarginalCoverage90']:.3f} & {rr['HybridCoverage90']:.3f} & {rr['HybridMAE']:.1f} \\\\")
    lines += [r'\bottomrule',r'\end{tabular}',r'}',rf'\begin{{flushleft}}\footnotesize Note: Across all 156 rolling origins, the training-only screen detected temporal signal in {signal_n}, the Gaussian temporal branch was eligible in {eligible_n}, and a temporal model ultimately replaced the marginal scenario generator in {selected_n}. The table lists only medicines with at least one selected temporal model. GARMA origins combine selected GARMA(1,0) and GARMA(2,0) specifications, with a linear time covariate when selected by AICc. No temporal model uses information from the held-out month.\end{{flushleft}}',r'\end{table}']
    (ROOT/'tables'/'revised'/'table_temporal_selection.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')

# Figure: marginal versus temporal-adaptive predictive intervals for two temporal examples.
fig,axes=plt.subplots(2,1,figsize=(10,7),sharex=True)
for ax,med in zip(axes,['M03','M09']):
    z=detail[detail.Medication==med].sort_values('TestMonth')
    ax.fill_between(z.TestMonth,z.MarginalP05,z.MarginalP95,alpha=.18,label='Marginal-AIC P05--P95')
    ax.plot(z.TestMonth,z.HybridP05,'--',lw=1.1,label='Temporal-adaptive P05')
    ax.plot(z.TestMonth,z.HybridP95,'--',lw=1.1,label='Temporal-adaptive P95')
    ax.plot(z.TestMonth,z.ActualDemand,'o-',lw=1.3,label='Held-out demand')
    mc=z.MarginalCovered90.mean();hc=z.HybridCovered90.mean()
    ax.set_title(f'{med}: marginal coverage {mc:.1%}; temporal-adaptive coverage {hc:.1%}')
    ax.set_ylabel('Requested demand')
    ax.legend(fontsize=8,ncol=2)
axes[-1].set_xlabel('Held-out month')
fig.tight_layout();fig.savefig(ROOT/'figures'/'revised'/'fig8_temporal_calibration.pdf',bbox_inches='tight');fig.savefig(ROOT/'figures'/'revised'/'fig8_temporal_calibration.png',dpi=320,bbox_inches='tight');plt.close(fig)

manifest_path=DATA/'analysis_manifest.json'
if manifest_path.exists():
    manifest=json.loads(manifest_path.read_text());manifest['scenario_calibration']={'marginal_selection':'minimum AIC among five marginal families at each rolling origin','temporal_adaptation':'training-window temporal screen followed by Gaussian GLM/GARMA AICc selection when eligible','predictive_interval':'5th to 95th percentile','coverage_evaluations':int(len(detail)),'temporal_signal_origins':int(detail.TemporalSignal.sum()),'gaussian_temporal_eligible_origins':int(detail.GaussianTemporalEligible.sum()),'temporal_models_selected':int(detail.TemporalSelected.sum()),'comparison_reference':'Rojas et al. 2019, PLOS ONE 14(3):e0212768'};manifest['generated_files']=sorted(str(x.relative_to(ROOT)) for folder in (DATA,ROOT/'tables'/'revised',ROOT/'figures'/'revised') for x in folder.glob('*') if not x.name.startswith('_'));manifest_path.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(summary_df.to_string(index=False));print('\nTemporal branch by medicine:\n',tsel.to_string(index=False));print('\nCost calibration:\n',cost_df.to_string(index=False))
