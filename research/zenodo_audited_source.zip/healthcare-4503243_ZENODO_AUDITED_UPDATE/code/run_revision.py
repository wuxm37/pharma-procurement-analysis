#!/usr/bin/env python3
"""Portable orchestrator for the Healthcare two-stage revision package.

This file intentionally imports no numerical libraries. Each numerical stage runs
in a fresh Python process, preventing optimizer state from carrying across extreme
Monte Carlo batches.
"""
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
ANALYSIS=ROOT/'code'/'01_revision_analysis.py'
VERIFY=ROOT/'code'/'02_verify_revision_outputs.py'
SCENARIO=ROOT/'code'/'03_scenario_accuracy.py'
N_CASES=900
BATCH=75
SEED=20260901

def run(*args):
    subprocess.run([sys.executable,str(ANALYSIS),*map(str,args)],check=True,cwd=ROOT)

def main():
    run('--stage','empirical','--simulation-cases',N_CASES,'--seed',SEED)
    for b in range((N_CASES+BATCH-1)//BATCH):
        run('--stage','simulation-batch','--simulation-cases',N_CASES,'--seed',SEED,'--batch-index',b,'--batch-size',BATCH)
    run('--stage','assemble','--simulation-cases',N_CASES,'--seed',SEED)
    subprocess.run([sys.executable,str(SCENARIO)],check=True,cwd=ROOT)
    subprocess.run([sys.executable,str(VERIFY)],check=True,cwd=ROOT)

if __name__=='__main__':
    main()
