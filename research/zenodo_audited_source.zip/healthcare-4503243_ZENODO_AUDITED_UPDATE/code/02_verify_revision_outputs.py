#!/usr/bin/env python3
"""Fail-fast validation for the Healthcare GARMA/two-stage revision outputs."""
from pathlib import Path
import json
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];DATA=ROOT/'data'/'revised';TABLES=ROOT/'tables'/'revised';FIGURES=ROOT/'figures'/'revised'
def require(path):
    if not path.exists() or path.stat().st_size==0: raise AssertionError(f'Missing or empty output: {path}')
for name in ['analysis_manifest.json','fit_full.csv','parameters.csv','profiles.csv','rolling_detail.csv','rolling_medicine.csv','rolling_summary.csv','simulation_cases.csv','simulation_summary.csv','tree_metrics.csv','temporal_selection.csv','scenario_accuracy_detail.csv','scenario_accuracy_summary.csv','scenario_cost_accuracy.csv','temporal_calibration_by_medicine.csv']:
    require(DATA/name)
for name in ['table_parameters.tex','table_profiles.tex','table_fit.tex','table_rolling_summary.tex','table_rolling_medicine.tex','table_scenario_accuracy.tex','table_temporal_selection.tex','table_simulation_summary.tex','table_tree_metrics.tex']:
    require(TABLES/name)
for stem in ['fig1_revised_workflow','fig2_demand_profiles','fig3_fitted_distributions','fig4_rolling_tradeoff','fig5_simulation_operational_winners','fig6_decision_tree','fig7_fit_operational_matrix','fig8_temporal_calibration']:
    require(FIGURES/f'{stem}.pdf');require(FIGURES/f'{stem}.png')
rolling=pd.read_csv(DATA/'rolling_detail.csv');simulation=pd.read_csv(DATA/'simulation_cases.csv');tree=pd.read_csv(DATA/'tree_metrics.csv');summary=pd.read_csv(DATA/'rolling_summary.csv');temporal=pd.read_csv(DATA/'temporal_selection.csv');scenario=pd.read_csv(DATA/'scenario_accuracy_detail.csv');ss=pd.read_csv(DATA/'scenario_accuracy_summary.csv');sc=pd.read_csv(DATA/'scenario_cost_accuracy.csv');manifest=json.loads((DATA/'analysis_manifest.json').read_text())
if rolling[['Medication','TestMonth']].drop_duplicates().shape[0]!=156: raise AssertionError('Expected 156 unique medicine-month origins')
for policy in ['Mean','Previous','SeasonalNaive']:
    if int((rolling.Policy==policy).sum())!=156: raise AssertionError(f'Baseline {policy} must have 156 rows')
if int(temporal.TemporalSignal.sum())!=82: raise AssertionError('Expected 82 training-only temporal-signal origins')
if int(temporal.GaussianTemporalEligible.sum())!=72: raise AssertionError('Expected 72 Gaussian-temporal-eligible origins')
if int(temporal.TemporalSelected.sum())!=46: raise AssertionError('Expected 46 origins where a temporal model replaced the marginal generator')
use=temporal[temporal.TemporalSelected]
if int(use.SelectedScenarioModel.str.contains('GARMA').sum())!=19: raise AssertionError('Expected GARMA to be selected at 19 rolling origins')
# 12 M01 GARMA + 4 M03 + 3 M09; remaining temporal origins are trend GLM.
required_groups={'Service-constrained 95/95','Service-constrained 99/99','Unconstrained economic (diagnostic)'}
if not required_groups.issubset(set(summary.PolicyGroup)): raise AssertionError('Policy summaries incomplete')
if len(simulation)!=900 or int(simulation.Tie.sum())!=666: raise AssertionError('900-case diagnostic simulation changed unexpectedly')
for c in ['AICCostRegretPct','AICShortageRate','AICOverstockRate','AICFillRate']:
    if c not in simulation.columns: raise AssertionError(f'Missing simulation operational metric: {c}')
if manifest.get('stochastic_program',{}).get('simulation_scenarios_per_fit')!=256: raise AssertionError('Simulation SAA scenario count must be 256 per candidate fit')
if tree.shape[0]!=1 or int(tree.loc[0,'TestN'])!=71: raise AssertionError('Tree validation output changed unexpectedly')
if len(scenario)!=156 or int(scenario.HybridCovered90.sum())!=138: raise AssertionError('Temporal-adaptive scenario calibration must contain 156 origins and 138 central-90% hits')
overall=ss[ss.Group=='Overall'].iloc[0]
if abs(float(overall.HybridCoverage90)-138/156)>1e-12: raise AssertionError('Overall temporal-adaptive coverage changed unexpectedly')
if abs(float(overall.MarginalCoverage90)-131/156)>1e-12: raise AssertionError('Marginal-AIC coverage changed unexpectedly')
if set(sc.Policy)!={'SC95','SC99'}: raise AssertionError('Cost calibration must contain SC95 and SC99')
if manifest.get('rolling_origins')!=12 or manifest.get('simulation_cases')!=900: raise AssertionError('Manifest settings mismatch')
print('Revision outputs verified: 156 rolling origins; 82 temporal signals, 72 Gaussian-eligible origins, 46 selected temporal models (19 GARMA); 138/156 adaptive central-90% hits; SC95/SC99 two-stage constraints; 900 diagnostic simulations with 256 SAA scenarios per candidate fit and explicit cost/shortage/overstock metrics; 9 generated tables and 8 PDF/PNG figures.')
